# 获取Jetbrains激活码

##### 使用方式 ```python -m idea.code -n```

