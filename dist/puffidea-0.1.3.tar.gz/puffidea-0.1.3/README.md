# 获取Jetbrains激活码

### 安装方式 
```pip install puffidea```
<br />

Or
<br /> 

```pip3 install puffieda```

<br />

### 使用方式 
```jtc``` (jetbrain code)<br />

### 构建方式:
##### ```python setup.py sdist bdist_wheel```
##### ```twine upload dist/*```

### 公众号(更新自动推送)
![MagicPuff](https://github.com/PeterPuffer/puffidea/blob/master/img/wx_qrcode.jpg)
