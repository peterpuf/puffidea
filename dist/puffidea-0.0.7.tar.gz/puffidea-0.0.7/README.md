# 获取Jetbrains激活码

### 安装方式 
```pip install puffidea```
<br />

Or
<br /> 

```pip3 install puffieda```

<br />

### 使用方式 
```python -m idea.code -h```

Or
<br /> 

```python3 -m idea.code -h```

<br />

### 构建方式:
##### ```python setup.py sdist bdist_wheel```
##### ```twine upload dist/*```